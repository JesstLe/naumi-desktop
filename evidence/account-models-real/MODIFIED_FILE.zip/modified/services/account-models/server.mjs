import http from 'node:http';
import {once} from 'node:events';
import {fault,publicRoute} from './registry.mjs';
import {AccountModelStream} from './stream.mjs';
const ROOT='/api/desktop-models/v1';
async function body(req,max=4*1024*1024){let n=0,chunks=[];for await(const c of req){n+=c.length;if(n>max)throw fault('ACCOUNT_MODEL_BODY_TOO_LARGE',413);chunks.push(c);}try{return JSON.parse(Buffer.concat(chunks));}catch{throw fault('ACCOUNT_MODEL_JSON_INVALID');}}
export function accountModelServer({store,registry,authenticate,origin,request=fetch}){
 const controllers=new Set();const server=http.createServer(async(req,res)=>{
 const send=(status,v)=>{if(!res.headersSent&&!res.destroyed)res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'}).end(JSON.stringify(v));};let requestId,started=false,controller;
 try{const url=new URL(req.url,'http://localhost');if(req.method==='GET'&&url.pathname==='/api/desktop-models/health')return send(200,{product:'Naumi Account Models',protocol:1});
 if(req.method==='GET'&&url.pathname==='/admin/desktop-models'){await authenticate(req,{admin:true});res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','Content-Security-Policy':"default-src 'none'; script-src 'self'; style-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'"}).end(await registry.adminHTML());return;}
 if(req.method==='GET'&&url.pathname==='/api/desktop-models/admin.js'){await authenticate(req,{admin:true});res.writeHead(200,{'Content-Type':'text/javascript','Cache-Control':'no-store'}).end(await registry.adminJS());return;}
 if(!url.pathname.startsWith(ROOT+'/'))return send(404,{error:'NOT_FOUND'});
 const gateway=url.pathname.match(/^\/api\/desktop-models\/v1\/gateway\/([a-zA-Z0-9_-]+)(\/.*)$/);
 if(gateway){if(req.method!=='POST'||req.headers.origin)throw fault('ACCOUNT_MODEL_GATEWAY_FORBIDDEN',403);const routes=await registry.list(),actor=store.authenticate(req.headers.authorization?.replace(/^Bearer /,'')??req.headers['x-api-key'],req.headers['x-naumi-device'],routes),route=routes.find(r=>r.id===gateway[1]);if(!route||!actor.routes.includes(route.id))throw fault('ACCOUNT_MODEL_ROUTE_DENIED',403);
 const suffix=route.api==='anthropic-messages'?'/v1/messages':route.api==='openai-responses'?'/responses':'/chat/completions';if(gateway[2]!==suffix)throw fault('ACCOUNT_MODEL_ENDPOINT_DENIED',403);
 const value=await body(req);if(!value||value.model!==route.model.id||value.store===true||typeof value.stream!=='boolean'||(value.max_tokens??value.max_output_tokens??value.max_completion_tokens??route.model.maxTokens)>route.model.maxTokens)throw fault('ACCOUNT_MODEL_REQUEST_INVALID');
 requestId=req.headers['x-naumi-request-id'];store.begin(actor,requestId,route.id);started=true;controller=new AbortController();controllers.add(controller);const gone=()=>{if(!res.writableEnded)controller.abort();};res.on('close',gone);
 try{const key=await registry.secret(route);if(typeof key!=='string'||!key||/[\x00-\x1f\x7f]/.test(key))throw fault('ACCOUNT_MODEL_UPSTREAM_CREDENTIAL_INVALID',503);
 const base=route.baseURL,suffixUp=route.api==='anthropic-messages'&&base.endsWith('/v1')?'/messages':suffix;const upstream=await request(base+suffixUp,{method:'POST',redirect:'error',headers:{'Content-Type':'application/json',...(route.api==='anthropic-messages'?{'x-api-key':key,'anthropic-version':'2023-06-01'}:{Authorization:'Bearer '+key})},body:JSON.stringify(route.api==='anthropic-messages'?Object.fromEntries(Object.entries(value).filter(([k])=>k!=='store')):{...value,store:false}),signal:AbortSignal.any([controller.signal,AbortSignal.timeout(300000)])});
 if(!upstream.ok){await upstream.body?.cancel();store.finish(requestId,[400,401,403,404,422,429].includes(upstream.status)?'rejected':'unknown');throw fault('ACCOUNT_MODEL_UPSTREAM_REJECTED',upstream.status===429?429:502);}
 const type=upstream.headers.get('content-type')??'';if(!(value.stream?type.includes('text/event-stream'):type.includes('application/json')))throw fault('ACCOUNT_MODEL_UPSTREAM_INVALID',502);
 if(!value.stream){const raw=await upstream.text();if(raw.length>32*1024*1024)throw fault('ACCOUNT_MODEL_RESPONSE_TOO_LARGE',502);let parsed;try{parsed=JSON.parse(raw);}catch{throw fault('ACCOUNT_MODEL_UPSTREAM_INVALID',502);}if(parsed.error)throw fault('ACCOUNT_MODEL_UPSTREAM_INVALID',502);store.finish(requestId,'stream_complete');send(200,parsed);return;}
 res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-store','X-Accel-Buffering':'no'});const completion=new AccountModelStream(route.api);for await(const chunk of upstream.body){const done=completion.push(chunk);if(!res.write(chunk))await once(res,'drain',{signal:controller.signal});if(done)break;}completion.finish();store.finish(requestId,'stream_complete');res.end();
 }finally{res.off('close',gone);controllers.delete(controller);}return;}
 const admin=url.pathname.startsWith(ROOT+'/admin/');const actor=await authenticate(req,{admin});
 if(req.method==='POST'&&(req.headers['x-naumi-account-models']!=='1'||req.headers.origin!==origin))throw fault('ACCOUNT_MODEL_SAME_ORIGIN_REQUIRED',403);
 if(req.method==='GET'&&url.pathname===ROOT+'/admin/catalog'){const routes=await registry.list();return send(200,{routes:routes.map(r=>publicRoute(r,origin)),unavailable:registry.unavailable??[]});}
 if(req.method==='GET'&&url.pathname===ROOT+'/admin/defaults')return send(200,store.defaults());
 if(req.method==='POST'&&url.pathname===ROOT+'/admin/defaults')return send(200,store.save(actor.subject,await body(req,32768),(await registry.list()).map(r=>r.id),{defaults:true}));
 if(req.method==='GET'&&url.pathname===ROOT+'/admin/grant'){const subject=url.searchParams.get('subject');if(!await registry.userExists(subject))throw fault('ACCOUNT_MODEL_ACCOUNT_NOT_FOUND',404);return send(200,store.grant(subject));}
 if(req.method==='POST'&&url.pathname===ROOT+'/admin/grant'){const input=await body(req,32768);if(!await registry.userExists(input.subject))throw fault('ACCOUNT_MODEL_ACCOUNT_NOT_FOUND',404);return send(200,store.save(actor.subject,input,(await registry.list()).map(r=>r.id)));}
 if(req.method==='POST'&&url.pathname===ROOT+'/bootstrap'){const input=await body(req,1024);if(!input||Object.keys(input).some(k=>k!=='deviceId'))throw fault('ACCOUNT_MODEL_BOOTSTRAP_INVALID');const v=store.authorize(actor.subject,input.deviceId,await registry.list());return send(200,{protocol:1,subject:actor.subject,deviceId:input.deviceId,revision:v.revision,expiresAt:v.expiresAt,token:v.token,routes:v.selected.map(r=>publicRoute(r,origin))});}
 send(404,{error:'NOT_FOUND'});
 }catch(e){if(started)store.finish(requestId,'unknown');controller?.abort();if(res.headersSent){res.destroy();return;}send(e.status??503,{error:/^(?:ACCOUNT_MODEL|MARKET)_[A-Z_]+$/.test(e.message)?e.message:'ACCOUNT_MODEL_UNAVAILABLE'});}
 });server.requestTimeout=30000;server.headersTimeout=10000;server.on('close',()=>{for(const c of controllers)c.abort();});return server;
}
